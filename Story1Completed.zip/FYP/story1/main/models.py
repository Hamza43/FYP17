from django.db import models

# Create your models here.
class TutorInfo(models.Model):
    tutor_id  = models.IntegerField(primary_key=True)
    tutor_name = models.CharField(max_length=150)
    city = models.CharField(max_length=200)
    street = models.CharField(max_length=200)
    country = models.CharField(max_length=80)
    def __str__(self):
        return self.tutor_name


class TutorExpertises(models.Model):
    tutor_id = models.ForeignKey(TutorInfo, on_delete=models.CASCADE)
    tutor_expertises = models.TextField()

    def __str__(self):
        return self.tutor_expertises