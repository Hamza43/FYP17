from rest_framework import serializers
from . models import TutorInfo, TutorExpertises

class TutorInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = TutorInfo
#        fields('city','street','country')
        #fields = ('city', 'street', 'country')
        fields = "__all__"