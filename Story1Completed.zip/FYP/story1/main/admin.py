from django.contrib import admin
from .models import TutorInfo, TutorExpertises

# Register your models here.
admin.site.register(TutorInfo)
admin.site.register(TutorExpertises)